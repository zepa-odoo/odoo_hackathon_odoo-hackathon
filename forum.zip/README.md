# StackIt - Q&A Forum Platform

A modern, full-stack Q&A web application built with Next.js and MongoDB, inspired by platforms like Quora and Stack Overflow.

## 🚀 Features

### Core Functionality
- **User Authentication**: Secure sign-up/sign-in with NextAuth.js
- **Question Management**: Ask, edit, and delete questions with rich text editing
- **Answer System**: Post answers with voting and acceptance
- **Rich Text Editor**: Tiptap-powered editor with formatting, links, images, and emojis
- **Voting System**: Upvote/downvote questions and answers
- **Tagging System**: Categorize questions with relevant tags
- **Search & Filter**: Find questions by title, content, or tags

### User Experience
- **Responsive Design**: Mobile-first design with Tailwind CSS
- **Real-time Notifications**: Get notified of new answers and mentions
- **User Profiles**: View user reputation and activity
- **Admin Panel**: Content moderation and user management (admin only)

### Technical Features
- **TypeScript**: Full type safety throughout the application
- **MongoDB Atlas**: Cloud database with automatic scaling
- **Next.js 14**: App Router with server-side rendering
- **Authentication**: JWT-based sessions with NextAuth
- **Form Validation**: Client and server-side validation
- **Error Handling**: Comprehensive error handling and user feedback

## 🛠️ Tech Stack

- **Frontend**: Next.js 14, React 18, TypeScript
- **Styling**: Tailwind CSS
- **Database**: MongoDB Atlas
- **Authentication**: NextAuth.js
- **Rich Text Editor**: Tiptap
- **Icons**: React Icons
- **Notifications**: React Hot Toast
- **Date Handling**: date-fns

## 📋 Prerequisites

- Node.js 18+ 
- npm or yarn
- MongoDB Atlas account (free tier available)

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone <repository-url>
cd stackit
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Environment Setup

Create a `.env.local` file in the root directory:

```env
# MongoDB Atlas
MONGODB_URI=mongodb+srv://your-username:your-password@your-cluster.mongodb.net/stackit?retryWrites=true&w=majority

# NextAuth
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your-nextauth-secret-key-here

# JWT
JWT_SECRET=your-jwt-secret-key-here
```

### 4. MongoDB Atlas Setup

1. Create a free account at [MongoDB Atlas](https://www.mongodb.com/atlas)
2. Create a new cluster (free tier)
3. Create a database user with read/write permissions
4. Get your connection string and add it to `.env.local`
5. Add your IP address to the IP whitelist

### 5. Generate Secrets

Generate secure random strings for your secrets:

```bash
# For NEXTAUTH_SECRET
openssl rand -base64 32

# For JWT_SECRET
openssl rand -base64 32
```

### 6. Run the Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### 7. Seed the Database (Optional)

Populate the database with sample data:

```bash
npm run seed
```

This creates:
- Admin user: `admin@stackit.com` / `admin123`
- Regular users: `john@example.com` / `password123`, etc.
- Sample questions and answers

## 📁 Project Structure

```
stackit/
├── app/                    # Next.js App Router
│   ├── api/               # API routes
│   ├── auth/              # Authentication pages
│   ├── globals.css        # Global styles
│   ├── layout.tsx         # Root layout
│   └── page.tsx           # Homepage
├── components/            # React components
│   ├── Header.tsx         # Navigation header
│   ├── QuestionCard.tsx   # Question preview card
│   ├── RichTextEditor.tsx # Tiptap editor
│   └── NotificationDropdown.tsx
├── lib/                   # Utility functions
│   └── mongodb.ts         # Database connection
├── models/                # MongoDB models
│   ├── User.ts
│   ├── Question.ts
│   ├── Answer.ts
│   └── Notification.ts
├── scripts/               # Database scripts
│   └── seed.ts           # Sample data
├── types/                 # TypeScript types
└── public/               # Static assets
```

## 🔐 User Roles

### Guest Users
- View all questions and answers
- Search and filter content
- Browse tags

### Registered Users
- All guest permissions
- Ask questions with rich text
- Answer questions
- Vote on content
- Accept answers to their questions
- Receive notifications

### Admin Users
- All user permissions
- Moderate content
- Ban users
- Send platform announcements
- Access admin dashboard

## 🎨 Customization

### Styling
The app uses Tailwind CSS for styling. Customize colors and components in:
- `tailwind.config.js` - Theme configuration
- `app/globals.css` - Custom CSS classes

### Rich Text Editor
The Tiptap editor can be extended with additional extensions. See `components/RichTextEditor.tsx` for current features.

### Database Models
MongoDB schemas are defined in the `models/` directory. Add new fields or validation as needed.

## 🚀 Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Connect your repository to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy!

### Other Platforms

The app can be deployed to any platform that supports Next.js:
- Netlify
- Railway
- DigitalOcean App Platform
- AWS Amplify

## 🔧 Development

### Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm run lint         # Run ESLint
npm run seed         # Seed database with sample data
```

### Code Style

The project uses:
- TypeScript for type safety
- ESLint for code linting
- Prettier for code formatting
- Conventional commit messages

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License.

## 🆘 Support

If you encounter any issues:

1. Check the [Issues](../../issues) page
2. Create a new issue with detailed information
3. Include your environment details and error messages

## 🙏 Acknowledgments

- [Next.js](https://nextjs.org/) for the amazing framework
- [MongoDB Atlas](https://www.mongodb.com/atlas) for the database
- [Tiptap](https://tiptap.dev/) for the rich text editor
- [Tailwind CSS](https://tailwindcss.com/) for the styling framework
- [NextAuth.js](https://next-auth.js.org/) for authentication

---

Built with ❤️ using Next.js and MongoDB 